package com.example.to_do_list.utils

object Constants {

    const val BASE_ACCESS_TOKEN="eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJlOGIzYzM1OWMxYWQ5ZjZjYTRlZjQzODI4YTNlYjgxMCIsInN1YiI6IjY1YTkxOTYzYTZkZGNiMDEzODI0ODk4OCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.Ec6fTjF-xWneZI4qTKyMrW1SBp3QVviIlDtE_T181fQ"
    const val BASE_URL = "https://dummyjson.com/"
}

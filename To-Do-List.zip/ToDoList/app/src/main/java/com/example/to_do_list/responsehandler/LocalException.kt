package com.example.to_do_list.responsehandler


data class LocalException(
    val message: String
)